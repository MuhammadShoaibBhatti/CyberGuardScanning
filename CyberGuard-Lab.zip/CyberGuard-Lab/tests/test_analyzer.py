from modules import packet_analyzer as pa, report_generator as rg
R = lambda t, s, p, dp, n=100: pa.PacketRecord(t, s, "9.9.9.9", p, 1000, dp, n)

def test_counts_and_filter():
    recs = [R(0, "1.1.1.1", "TCP", 80), R(1, "1.1.1.1", "UDP", 53), R(2, "2.2.2.2", "ICMP", None), R(3, "2.2.2.2", "GRE", None)]
    assert pa.protocol_counts(recs) == {"TCP": 1, "UDP": 1, "ICMP": 1, "ARP": 0, "OTHER": 1}
    assert len(pa.filter_records(recs, "TCP")) == 1
    assert len(pa.filter_records(recs, "All", "2.2.2.2")) == 2

def test_empty():
    assert pa.length_stats([]) == {} and pa.over_time([]) == [] and pa.indicators([]) == []

def test_indicator_wording():
    recs = [R(i, "5.5.5.5", "TCP", 1000 + i) for i in range(60)]
    assert "investigate" in pa.indicators(recs)[0]

def test_exports(tmp_path):
    recs = [R(0, "1.1.1.1", "TCP", 80)]
    s = rg.build_summary(recs, 5, {"proto": "All"})
    assert rg.export_csv(recs, tmp_path / "a.csv").read_text().startswith("time,src")
    assert rg.export_json(s, tmp_path / "a.json").exists()
    assert rg.export_pdf(s, tmp_path / "a.pdf").stat().st_size > 0

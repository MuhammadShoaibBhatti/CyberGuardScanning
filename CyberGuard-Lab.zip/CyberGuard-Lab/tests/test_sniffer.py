import pytest
pytest.importorskip("scapy")
from scapy.all import Ether, IP, TCP, Raw
from modules.network_sniffer import packet_to_record

def test_payload_not_kept():
    rec = packet_to_record(Ether() / IP(src="1.2.3.4", dst="5.6.7.8") / TCP(sport=1234, dport=80) / Raw(b"password=secret"))
    assert (rec.src, rec.proto, rec.dport) == ("1.2.3.4", "TCP", 80)
    assert not hasattr(rec, "payload") and "secret" not in str(rec)

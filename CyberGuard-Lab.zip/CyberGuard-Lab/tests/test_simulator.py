from modules.keylog_simulator import KeyLabSimulator

def test_ignores_events_when_stopped():
    s = KeyLabSimulator()
    assert s.record("a", "a") is None and s.events == []

def test_records_when_running_and_exports(tmp_path):
    s = KeyLabSimulator(); s.start()
    assert "a" in s.record("a", "a")
    assert "<Return>" in s.record("Return", "\r")
    assert s.export(tmp_path / "d.json").exists()
    s.clear(); assert s.events == []

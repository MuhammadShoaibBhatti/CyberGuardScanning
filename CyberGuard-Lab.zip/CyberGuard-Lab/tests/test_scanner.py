import socket, threading
import pytest
from modules import port_scanner as ps

def test_target_rules():
    assert ps.validate_target("127.0.0.1") == "127.0.0.1"
    with pytest.raises(ValueError): ps.validate_target("8.8.8.8")

def test_parse_ports():
    assert ps.parse_ports("80,443") == [80, 443] and ps.parse_ports("20-22") == [20, 21, 22]
    assert 443 in ps.parse_ports("common")
    with pytest.raises(ValueError): ps.parse_ports("0-5")

def test_finds_open_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); s.listen(); port = s.getsockname()[1]
    try:
        assert ps.scan("127.0.0.1", [port], lambda p, n: None, threading.Event())[0][0] == port
    finally: s.close()

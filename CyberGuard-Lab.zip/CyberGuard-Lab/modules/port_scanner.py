"""Simple, visible TCP connect scanner + ARP device discovery.
Safety: private/loopback targets only, no stealth tricks, capped size."""
from __future__ import annotations
import ipaddress
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Callable

SERVICES = {20: "FTP-data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 67: "DHCP", 80: "HTTP", 110: "POP3",
            123: "NTP", 135: "RPC", 139: "NetBIOS", 143: "IMAP", 161: "SNMP", 389: "LDAP", 443: "HTTPS", 445: "SMB",
            465: "SMTPS", 587: "SMTP-submit", 993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 3306: "MySQL", 3389: "RDP",
            5432: "PostgreSQL", 5900: "VNC", 8000: "HTTP-alt", 8080: "HTTP-proxy", 8443: "HTTPS-alt"}
MAX_PORTS = 5000

def validate_target(text: str) -> str:
    ip = ipaddress.ip_address(text.strip())
    if not (ip.is_private or ip.is_loopback):
        raise ValueError("Only private/local IPs (like 192.168.x.x or 127.0.0.1) are allowed.")
    return str(ip)

def parse_ports(spec: str) -> list[int]:
    spec = spec.strip().lower()
    if spec == "common":
        return sorted(SERVICES)
    ports: set[int] = set()
    for part in spec.split(","):
        a, _, b = part.strip().partition("-")
        lo, hi = int(a), int(b or a)
        if not (1 <= lo <= hi <= 65535):
            raise ValueError("Ports must be between 1 and 65535.")
        ports.update(range(lo, hi + 1))
    if not ports or len(ports) > MAX_PORTS:
        raise ValueError(f"Choose 1 to {MAX_PORTS} ports.")
    return sorted(ports)

def scan(target: str, ports: list[int], on_open: Callable[[int, str], None], stop: threading.Event,
         timeout: float = 0.6, workers: int = 100) -> list[tuple[int, str]]:
    found: list[tuple[int, str]] = []
    def probe(p: int) -> None:
        if stop.is_set():
            return
        try:
            with socket.create_connection((target, p), timeout=timeout):
                svc = SERVICES.get(p, "unknown")
                found.append((p, svc)); on_open(p, svc)
        except OSError:
            pass
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(probe, ports))
    return sorted(found)

def arp_discover(cidr: str) -> list[tuple[str, str]]:
    """Find devices on your own LAN with ARP (needs Npcap + Administrator)."""
    net = ipaddress.ip_network(cidr.strip(), strict=False)
    if not net.is_private or net.prefixlen < 24:
        raise ValueError("Use a private network of /24 or smaller, like 192.168.1.0/24.")
    from scapy.all import ARP, Ether, srp
    answered = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=str(net)), timeout=2, verbose=False)[0]
    return sorted((r.psrc, r.hwsrc) for _, r in answered)

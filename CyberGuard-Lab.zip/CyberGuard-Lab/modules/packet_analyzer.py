"""Pure analysis of packet METADATA. No payloads are ever stored."""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from modules.port_scanner import SERVICES

@dataclass(frozen=True)
class PacketRecord:
    time: float
    src: str
    dst: str
    proto: str
    sport: int | None
    dport: int | None
    length: int

def protocol_counts(recs) -> dict[str, int]:
    c = Counter(r.proto for r in recs)
    out = {p: c.get(p, 0) for p in ("TCP", "UDP", "ICMP", "ARP")}
    out["OTHER"] = sum(v for k, v in c.items() if k not in out)
    return out

def top(recs, field: str, n: int = 5) -> list[tuple]:
    return Counter(getattr(r, field) for r in recs if getattr(r, field) not in (None, "-")).most_common(n)

def services(recs, n: int = 6) -> list[tuple[str, int]]:
    c = Counter(SERVICES.get(r.dport, f"port {r.dport}") for r in recs if r.dport)
    return c.most_common(n)

def length_stats(recs) -> dict[str, float]:
    L = [r.length for r in recs]
    return {"min": min(L), "max": max(L), "avg": round(sum(L) / len(L), 1)} if L else {}

def over_time(recs, bucket: float = 1.0) -> list[tuple[float, int]]:
    if not recs:
        return []
    t0 = min(r.time for r in recs)
    c = Counter(int((r.time - t0) // bucket) for r in recs)
    return [(k * bucket, c.get(k, 0)) for k in range(max(c) + 1)]

def filter_records(recs, proto: str = "All", text: str = ""):
    t = text.strip().lower()
    def ok(r):
        if proto != "All" and r.proto != proto:
            return False
        return not t or t in f"{r.src} {r.dst} {r.sport} {r.dport}".lower()
    return [r for r in recs if ok(r)]

def indicators(recs) -> list[str]:
    """Hints that NEED investigation. They are not proof of an attack."""
    out = []
    ports: dict[str, set] = {}
    for r in recs:
        if r.dport and r.proto in ("TCP", "UDP"):
            ports.setdefault(r.src, set()).add(r.dport)
    for ip, p in ports.items():
        if len(p) >= 50:
            out.append(f"{ip} contacted {len(p)} different ports. This can be a scan, or a normal busy app. Please investigate.")
    return out

"""CSV / JSON / PDF exports. Metadata only."""
from __future__ import annotations
import csv
import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from modules import packet_analyzer as pa

NOTICE = "For authorized lab use only. Data is local metadata (no payloads). Alerts are indicators, not proof."

def stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def build_summary(recs, duration: float, filters: dict) -> dict:
    return {"created": datetime.now().isoformat(timespec="seconds"), "duration_seconds": round(duration, 1),
            "packets": len(recs), "protocols": pa.protocol_counts(recs), "length_stats": pa.length_stats(recs),
            "top_sources": pa.top(recs, "src"), "top_destinations": pa.top(recs, "dst"),
            "filters": filters, "notice": NOTICE}

def export_csv(recs, path: Path) -> Path:
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["time", "src", "dst", "proto", "sport", "dport", "length"])
        w.writeheader()
        for r in recs:
            w.writerow(asdict(r))
    return path

def export_scan(rows, path: Path) -> Path:
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["port", "service"]); w.writerows(rows)
    return path

def export_json(summary: dict, path: Path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(summary, indent=2), "utf-8")
    return path

def export_pdf(summary: dict, path: Path) -> Path:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    path = Path(path)
    c = canvas.Canvas(str(path), pagesize=A4)
    y = 800
    c.setFont("Helvetica-Bold", 16); c.drawString(50, y, "CyberGuard Lab - Session Report"); y -= 30
    c.setFont("Helvetica", 10)
    for k in ("created", "duration_seconds", "packets", "protocols", "length_stats", "filters", "notice"):
        c.drawString(50, y, f"{k}: {summary[k]}"[:110]); y -= 18
    c.save()
    return path

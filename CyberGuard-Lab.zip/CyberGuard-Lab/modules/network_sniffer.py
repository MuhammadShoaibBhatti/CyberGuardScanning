"""Metadata-only packet capture (Scapy + Npcap). Payload is never read or kept."""
from __future__ import annotations
import logging
import threading
from typing import Callable
from modules.packet_analyzer import PacketRecord

log = logging.getLogger(__name__)

def list_interfaces() -> dict[str, str]:
    """Return {friendly name: scapy interface name}. Empty if Scapy/Npcap is missing."""
    try:
        from scapy.all import conf
        return {(getattr(i, "description", "") or i.name): i.name for i in conf.ifaces.values()}
    except Exception as exc:
        log.warning("Cannot list interfaces: %s", exc)
        return {}

def packet_to_record(pkt) -> PacketRecord:
    from scapy.layers.inet import IP, TCP, UDP, ICMP
    from scapy.layers.inet6 import IPv6
    ip = pkt[IP] if IP in pkt else pkt[IPv6] if IPv6 in pkt else None
    src, dst = (ip.src, ip.dst) if ip is not None else ("-", "-")
    proto, sp, dp = "OTHER", None, None
    from scapy.layers.l2 import ARP
    if ip is None and ARP in pkt:
        return PacketRecord(float(pkt.time), pkt[ARP].psrc, pkt[ARP].pdst, "ARP", None, None, len(pkt))
    if TCP in pkt: proto, sp, dp = "TCP", pkt[TCP].sport, pkt[TCP].dport
    elif UDP in pkt: proto, sp, dp = "UDP", pkt[UDP].sport, pkt[UDP].dport
    elif ICMP in pkt: proto = "ICMP"
    return PacketRecord(float(pkt.time), src, dst, proto, sp, dp, len(pkt))

class Sniffer:
    def __init__(self) -> None:
        self._s = None
        self.running = False

    def start(self, iface: str | None, duration: int, on_packet: Callable, on_error: Callable, on_done: Callable) -> None:
        if self.running:
            return
        try:
            from scapy.all import AsyncSniffer
            self._s = AsyncSniffer(iface=iface, store=False, prn=lambda p: on_packet(packet_to_record(p)))
            self._s.start()
        except PermissionError:
            on_error("Permission denied. Close the app and run PowerShell as Administrator.")
            return
        except Exception as exc:
            on_error(f"Capture could not start: {exc}. Check that Npcap is installed and you are Administrator.")
            return
        self.running = True
        threading.Thread(target=self._wait, args=(duration, on_error, on_done), daemon=True).start()

    def _wait(self, duration, on_error, on_done) -> None:
        try:
            self._s.join(timeout=duration)
            self.stop()
        except Exception as exc:
            on_error(f"Capture stopped with an error: {exc}")
        self.running = False
        on_done()

    def stop(self) -> None:
        try:
            if self._s is not None and self._s.running:
                self._s.stop()
        except Exception as exc:
            log.warning("Stop error: %s", exc)

"""SAFE key-event simulator. It only records what the UI gives it from ONE test textbox.
It has no system hooks, no background listener and no access to other apps."""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path

class KeyLabSimulator:
    def __init__(self) -> None:
        self.running = False
        self.events: list[dict] = []

    def start(self) -> None: self.running = True
    def stop(self) -> None: self.running = False
    def clear(self) -> None: self.events.clear()

    def record(self, keysym: str, char: str = "") -> str | None:
        """Called only by the lab textbox. Ignored unless the test is running."""
        if not self.running:
            return None
        shown = char if char and char.isprintable() else f"<{keysym}>"
        self.events.append({"time": datetime.now().strftime("%H:%M:%S"), "key": shown})
        return f"{self.events[-1]['time']}  key event: {shown}"

    def export(self, path: Path) -> Path:
        path = Path(path)
        path.write_text(json.dumps({"note": "DEMO LOG from the in-app simulator", "events": self.events}, indent=2), "utf-8")
        return path

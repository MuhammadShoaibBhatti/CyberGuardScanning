"""Colors and fonts for the hacker-style dark theme."""
C = {
    "bg": "#080D0B", "side": "#0B120F", "card": "#101C17", "accent": "#39FF98",
    "green": "#00F58A", "cyan": "#49D8FF", "purple": "#B69CFF",
    "warn": "#FFD166", "error": "#FF5577", "text": "#E8FFF1", "muted": "#8AA899",
}
MONO = ("Consolas", 12)
UI = ("Segoe UI", 13)
PROTO_COLORS = {"TCP": C["cyan"], "UDP": C["purple"], "ICMP": C["warn"], "ARP": C["green"], "OTHER": C["muted"]}

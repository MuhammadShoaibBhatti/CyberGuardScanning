"""Safe, validated settings saved to data/settings.json."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FILE = ROOT / "data" / "settings.json"
DEFAULTS = {"duration": 30, "export_dir": str(ROOT / "reports"), "row_limit": 500, "confirm": True, "accent": "#39FF98"}

def validate(raw: dict) -> dict:
    s = dict(DEFAULTS)
    try:
        s["duration"] = min(3600, max(5, int(raw.get("duration", 30))))
        s["row_limit"] = min(5000, max(50, int(raw.get("row_limit", 500))))
    except (TypeError, ValueError):
        pass
    s["confirm"] = bool(raw.get("confirm", True))
    d = Path(str(raw.get("export_dir", DEFAULTS["export_dir"]))).expanduser()
    s["export_dir"] = str(d) if d.is_dir() else DEFAULTS["export_dir"]
    acc = str(raw.get("accent", ""))
    s["accent"] = acc if acc in ("#39FF98", "#49D8FF", "#B69CFF") else DEFAULTS["accent"]
    return s

def load() -> dict:
    try:
        return validate(json.loads(FILE.read_text("utf-8")))
    except (OSError, ValueError):
        return dict(DEFAULTS)

def save(s: dict) -> None:
    FILE.parent.mkdir(exist_ok=True)
    FILE.write_text(json.dumps(validate(s), indent=2), "utf-8")

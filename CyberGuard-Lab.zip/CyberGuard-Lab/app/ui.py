"""CyberGuard Lab main window (CustomTkinter). UI only; logic lives in modules/."""
from __future__ import annotations
import queue
import time
from datetime import datetime
from pathlib import Path
from tkinter import messagebox
import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from app import settings
from app.theme import C, MONO, UI, PROTO_COLORS
import csv, threading
from modules import packet_analyzer as pa, report_generator as rg, port_scanner as ps
from modules.keylog_simulator import KeyLabSimulator
from modules.network_sniffer import Sniffer, list_interfaces

PAGES = ["Dashboard", "Network Sniffer", "Port Scanner", "Packet Analyzer", "Traffic Analytics", "Safe Key Lab", "Reports & Exports", "Settings", "About & Ethics"]
ETHICS = ("CyberGuard Lab is for learning and for networks you OWN or have written permission to test.\n\n"
          "What it does: reads packet metadata (who talked to whom, protocol, port, size).\n"
          "What it never does: read payloads, passwords, cookies or tokens; run hidden; upload data; watch other apps.\n"
          "Alerts are hints to investigate, not proof of an attack.\n\n"
          "Needs: Npcap installed + PowerShell/Terminal run as Administrator for live capture.")

class Chart(ctk.CTkFrame):
    def __init__(self, master, title, draw):
        super().__init__(master, fg_color=C["card"], corner_radius=14, border_width=1, border_color="#1c3a2c")
        self.title, self.draw = title, draw
        self.fig = Figure(figsize=(4, 2.8), facecolor=C["card"])
        self.cv = FigureCanvasTkAgg(self.fig, self)
        self.cv.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)

    def refresh(self, recs):
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(C["card"]); ax.set_title(self.title, color=C["accent"], fontsize=10)
        ax.tick_params(colors=C["muted"], labelsize=8)
        for s in ax.spines.values(): s.set_color("#1c3a2c")
        if recs:
            self.draw(ax, recs)
        else:
            ax.text(.5, .5, "No data yet.\nStart a capture.", ha="center", va="center", color=C["muted"], transform=ax.transAxes)
            ax.set_xticks([]); ax.set_yticks([])
        self.fig.tight_layout(); self.cv.draw_idle()

def d_proto(ax, recs):
    pc = {k: v for k, v in pa.protocol_counts(recs).items() if v}
    ax.pie(list(pc.values()), labels=list(pc), colors=[PROTO_COLORS[k] for k in pc], textprops={"color": C["text"], "fontsize": 8},
           wedgeprops={"width": .42, "edgecolor": C["card"]})
def d_time(ax, recs):
    pts = pa.over_time(recs); x, y = [p[0] for p in pts], [p[1] for p in pts]
    ax.plot(x, y, color=C["accent"]); ax.fill_between(x, y, color=C["accent"], alpha=.2)
def d_ips(ax, recs):
    t = pa.top(recs, "src", 5) + pa.top(recs, "dst", 5)
    ax.barh([a for a, _ in t], [b for _, b in t], color=[C["cyan"]] * min(5, len(t)) + [C["purple"]] * 5)
def d_ports(ax, recs):
    t = pa.top(recs, "dport", 8); ax.bar([str(a) for a, _ in t], [b for _, b in t], color=C["warn"])
def d_len(ax, recs):
    ax.hist([r.length for r in recs], bins=20, color=C["green"])

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.cfg = settings.load()
        C["accent"] = self.cfg["accent"]
        self.title("CyberGuard Lab"); self.geometry("1200x740"); self.minsize(1000, 640); self.configure(fg_color=C["bg"])
        self.recs: list[pa.PacketRecord] = []; self.q: queue.Queue = queue.Queue()
        self.sniffer, self.sim = Sniffer(), KeyLabSimulator()
        self.ifaces = list_interfaces(); self.t0 = 0.0; self.dur = 0.0; self.reports = 0; self.events = 0
        self.current = "Dashboard"; self.pages: dict[str, ctk.CTkFrame] = {}; self.nav: dict[str, ctk.CTkButton] = {}
        self.charts: dict[str, Chart] = {}
        self._build_shell()
        for name, fn in zip(PAGES, [self.p_dash, self.p_sniff, self.p_scan, self.p_analyzer, self.p_charts, self.p_key, self.p_reports, self.p_settings, self.p_about]):
            f = ctk.CTkFrame(self.main, fg_color="transparent"); self.pages[name] = f; fn(f)
        self.show("Dashboard"); self.after(500, self.tick)

    # ---------- helpers ----------
    def label(self, p, text, color=None, font=UI, **kw): return ctk.CTkLabel(p, text=text, text_color=color or C["text"], font=font, **kw)
    def button(self, p, text, cmd, color=None):
        return ctk.CTkButton(p, text=text, command=cmd, fg_color=color or "#14271f", hover_color="#1f4a38", text_color=C["text"],
                             border_width=1, border_color=C["accent"], corner_radius=10)
    def card(self, p): return ctk.CTkFrame(p, fg_color=C["card"], corner_radius=14, border_width=1, border_color="#1c3a2c")
    def term(self, p, h=200):
        return ctk.CTkTextbox(p, height=h, fg_color="#050806", text_color=C["accent"], font=MONO, border_width=1, border_color="#1c3a2c")
    def put(self, box, text):
        box.configure(state="normal"); box.delete("1.0", "end"); box.insert("end", text); box.configure(state="disabled")

    def _build_shell(self):
        top = ctk.CTkFrame(self, height=48, fg_color=C["side"], corner_radius=0); top.pack(fill="x")
        self.label(top, "▌CYBERGUARD LAB", C["accent"], ("Consolas", 18, "bold")).pack(side="left", padx=16)
        self.clock = self.label(top, "", C["muted"]); self.clock.pack(side="right", padx=12)
        self.iface_lbl = self.label(top, "Interface: none", C["cyan"]); self.iface_lbl.pack(side="right", padx=12)
        self.status = self.label(top, "● IDLE", C["muted"]); self.status.pack(side="right", padx=12)
        self.label(top, "LOCAL LAB • AUTHORIZED USE ONLY", C["warn"], ("Consolas", 11, "bold")).pack(side="right", padx=12)
        body = ctk.CTkFrame(self, fg_color="transparent"); body.pack(fill="both", expand=True)
        side = ctk.CTkFrame(body, width=200, fg_color=C["side"], corner_radius=0); side.pack(side="left", fill="y"); side.pack_propagate(False)
        for n in PAGES:
            b = ctk.CTkButton(side, text="  " + n, anchor="w", height=38, fg_color="transparent", hover_color="#14271f",
                              text_color=C["muted"], corner_radius=8, command=lambda n=n: self.show(n))
            b.pack(fill="x", padx=10, pady=3); self.nav[n] = b
        self.main = ctk.CTkFrame(body, fg_color="transparent"); self.main.pack(side="left", fill="both", expand=True, padx=14, pady=12)

    def show(self, name):
        for f in self.pages.values(): f.pack_forget()
        self.pages[name].pack(fill="both", expand=True); self.current = name
        for n, b in self.nav.items():
            b.configure(fg_color="#14271f" if n == name else "transparent", text_color=C["accent"] if n == name else C["muted"])
        self.refresh_page()

    def filtered(self): return pa.filter_records(self.recs, self.proto_var.get(), self.search.get())

    # ---------- pages ----------
    def p_dash(self, f):
        row = ctk.CTkFrame(f, fg_color="transparent"); row.pack(fill="x"); self.cards = {}
        for k in ("Packets", "TCP", "UDP", "ICMP", "Other", "Duration", "Events", "Reports"):
            c = self.card(row); c.pack(side="left", expand=True, fill="x", padx=3)
            v = self.label(c, "0", C["accent"], ("Consolas", 20, "bold")); v.pack(pady=(8, 0)); self.label(c, k, C["muted"], ("Segoe UI", 11)).pack(pady=(0, 8)); self.cards[k] = v
        mid = ctk.CTkFrame(f, fg_color="transparent"); mid.pack(fill="both", expand=True, pady=8)
        self.charts["d1"] = Chart(mid, "Protocol distribution", d_proto); self.charts["d1"].pack(side="left", fill="both", expand=True, padx=3)
        self.charts["d2"] = Chart(mid, "Packets over time", d_time); self.charts["d2"].pack(side="left", fill="both", expand=True, padx=3)
        self.label(f, "Recent capture events (live data only)", C["muted"]).pack(anchor="w")
        self.recent = self.term(f, 150); self.recent.pack(fill="x")

    def p_sniff(self, f):
        bar = self.card(f); bar.pack(fill="x")
        names = list(self.ifaces) or ["No interface found (install Npcap)"]
        self.iface_var = ctk.StringVar(value=names[0]); self.dur_var = ctk.StringVar(value=str(self.cfg["duration"]))
        ctk.CTkOptionMenu(bar, values=names, variable=self.iface_var, width=260, fg_color="#14271f", button_color="#1f4a38").pack(side="left", padx=8, pady=8)
        self.label(bar, "Seconds:", C["muted"]).pack(side="left"); ctk.CTkEntry(bar, textvariable=self.dur_var, width=60).pack(side="left", padx=4)
        self.button(bar, "▶ Start", self.start_cap).pack(side="left", padx=4); self.button(bar, "■ Stop", self.stop_cap, "#3a1520").pack(side="left", padx=4)
        bar2 = self.card(f); bar2.pack(fill="x", pady=6)
        self.proto_var = ctk.StringVar(value="All"); self.search = ctk.CTkEntry(bar2, placeholder_text="Search IP or port...", width=260)
        self.search.pack(side="left", padx=8, pady=8)
        ctk.CTkOptionMenu(bar2, values=["All", "TCP", "UDP", "ICMP", "ARP", "OTHER"], variable=self.proto_var, width=100, fg_color="#14271f").pack(side="left")
        self.msg = self.label(bar2, "Needs Npcap + Administrator for live capture.", C["warn"], ("Segoe UI", 11)); self.msg.pack(side="left", padx=10)
        self.sniff_box = self.term(f, 400); self.sniff_box.pack(fill="both", expand=True)

    def p_analyzer(self, f):
        self.button(f, "Refresh analysis", self.refresh_page).pack(anchor="w", pady=4)
        self.an_box = self.term(f, 500); self.an_box.pack(fill="both", expand=True)

    def p_charts(self, f):
        g = ctk.CTkFrame(f, fg_color="transparent"); g.pack(fill="both", expand=True)
        for i, (k, t, fn) in enumerate([("a1", "Protocols", d_proto), ("a2", "Packets over time", d_time), ("a3", "Top source (blue) / destination (purple)", d_ips),
                                        ("a4", "Frequent destination ports", d_ports), ("a5", "Packet length", d_len)]):
            self.charts[k] = Chart(g, t, fn); self.charts[k].grid(row=i // 3, column=i % 3, sticky="nsew", padx=3, pady=3)
        for i in range(3): g.columnconfigure(i, weight=1)
        for i in range(2): g.rowconfigure(i, weight=1)

    def p_key(self, f):
        self.label(f, "⚠ SIMULATOR ONLY: records keys typed in the box below, nothing else. Do not type real passwords.", C["warn"]).pack(anchor="w")
        bar = ctk.CTkFrame(f, fg_color="transparent"); bar.pack(fill="x", pady=6)
        for t, c in [("Start Test", self.key_start), ("Stop Test", self.key_stop), ("Clear Log", self.key_clear), ("Export Demo Log", self.key_export)]:
            self.button(bar, t, c).pack(side="left", padx=3)
        self.key_in = ctk.CTkTextbox(f, height=110, fg_color="#050806", text_color=C["text"], font=MONO, border_width=1, border_color=C["warn"])
        self.key_in.pack(fill="x"); self.key_in.configure(state="disabled"); self.key_in.bind("<KeyPress>", self.on_key, add="+")
        self.key_log = self.term(f, 300); self.key_log.pack(fill="both", expand=True, pady=6)

    def p_reports(self, f):
        self.label(f, "Export the current session (metadata only).", C["muted"]).pack(anchor="w")
        for t, c in [("Export CSV (packets)", "csv"), ("Export JSON (summary)", "json"), ("Export PDF report", "pdf")]:
            self.button(f, t, lambda c=c: self.export(c)).pack(anchor="w", pady=4)
        self.rep_lbl = self.label(f, "No export yet.", C["cyan"]); self.rep_lbl.pack(anchor="w", pady=8)

    def p_settings(self, f):
        self.s_dur = ctk.StringVar(value=str(self.cfg["duration"])); self.s_dir = ctk.StringVar(value=self.cfg["export_dir"])
        self.s_rows = ctk.StringVar(value=str(self.cfg["row_limit"])); self.s_conf = ctk.BooleanVar(value=self.cfg["confirm"]); self.s_acc = ctk.StringVar(value=self.cfg["accent"])
        for t, v in [("Default capture seconds (5-3600)", self.s_dur), ("Export folder", self.s_dir), ("Table row limit (50-5000)", self.s_rows)]:
            self.label(f, t, C["muted"]).pack(anchor="w", pady=(8, 0)); ctk.CTkEntry(f, textvariable=v, width=420).pack(anchor="w")
        self.label(f, "Accent color (applies after restart)", C["muted"]).pack(anchor="w", pady=(8, 0))
        ctk.CTkOptionMenu(f, values=["#39FF98", "#49D8FF", "#B69CFF"], variable=self.s_acc, fg_color="#14271f").pack(anchor="w")
        ctk.CTkCheckBox(f, text="Ask before starting a capture", variable=self.s_conf).pack(anchor="w", pady=10)
        self.button(f, "Save settings", self.save_cfg).pack(anchor="w"); self.button(f, "Clear session history", self.clear_hist, "#3a1520").pack(anchor="w", pady=8)

    def p_about(self, f):
        b = self.term(f, 400); b.pack(fill="both", expand=True); self.put(b, ETHICS)

    # ---------- actions ----------
    def start_cap(self):
        try: secs = min(3600, max(5, int(self.dur_var.get())))
        except ValueError: return self.msg.configure(text="Seconds must be a number.", text_color=C["error"])
        if self.sniffer.running: return
        if self.cfg["confirm"] and not messagebox.askyesno("Authorized use", "Capture only on networks you own or may test.\nStart capture?"): return
        self.recs.clear(); self.t0 = time.time(); self.dur = 0
        name = self.iface_var.get(); self.iface_lbl.configure(text=f"Interface: {name[:28]}")
        self.sniffer.start(self.ifaces.get(name), secs, self.q.put, lambda m: self.q.put(("error", m)), lambda: self.q.put(("done", "")))
        if self.sniffer.running: self.msg.configure(text="Capturing...", text_color=C["accent"]); self.events += 1

    def stop_cap(self): self.sniffer.stop()

    def tick(self):
        self.clock.configure(text=datetime.now().strftime("%H:%M:%S"))
        try:
            while True:
                item = self.q.get_nowait()
                if isinstance(item, tuple) and item[0] == "scan":
                    self.sc_log(item[1])
                elif isinstance(item, tuple):
                    self.msg.configure(text=item[1] or "Capture finished.", text_color=C["error"] if item[0] == "error" else C["cyan"]); self.events += 1
                else:
                    self.recs.append(item)
        except queue.Empty:
            pass
        if self.sniffer.running: self.dur = time.time() - self.t0
        run = self.sniffer.running
        self.status.configure(text="● CAPTURING" if run and int(time.time()) % 2 else "● CAPTURING" if run else "● IDLE", text_color=C["accent"] if run else C["muted"])
        self.refresh_page(light=True); self.after(1000, self.tick)

    def refresh_page(self, light=False):
        pc = pa.protocol_counts(self.recs)
        for k, v in {"Packets": len(self.recs), "TCP": pc["TCP"], "UDP": pc["UDP"], "ICMP": pc["ICMP"], "Other": pc["OTHER"], "Duration": f"{self.dur:.0f}s", "Events": self.events, "Reports": self.reports}.items():
            self.cards[k].configure(text=str(v))
        n, lim = self.current, self.cfg["row_limit"]
        if n == "Dashboard":
            self.charts["d1"].refresh(self.recs); self.charts["d2"].refresh(self.recs)
            self.put(self.recent, self.rows(self.recs[-6:]) or "No live capture data yet.")
        elif n == "Network Sniffer": self.put(self.sniff_box, self.rows(self.filtered()[-lim:]) or "No packets. Pick an interface and press Start.")
        elif n == "Packet Analyzer" and not light: self.put(self.an_box, self.analysis())
        elif n == "Traffic Analytics":
            for k in ("a1", "a2", "a3", "a4", "a5"): self.charts[k].refresh(self.recs)

    @staticmethod
    def rows(recs):
        return "\n".join(f"{datetime.fromtimestamp(r.time):%H:%M:%S}  {r.src:>15}:{r.sport or '-':<5} -> {r.dst:>15}:{r.dport or '-':<5} {r.proto:<5} {r.length}B" for r in recs)

    def analysis(self):
        if not self.recs: return "No data yet. Run a capture first."
        r = self.recs
        out = [f"Packets: {len(r)}", f"Protocols: {pa.protocol_counts(r)}", f"Size (bytes): {pa.length_stats(r)}",
               f"Top sources: {pa.top(r, 'src')}", f"Top destinations: {pa.top(r, 'dst')}", f"Top destination ports: {pa.top(r, 'dport')}", f"Top services (HTTP, HTTPS, DNS, FTP...): {pa.services(r)}", "",
               "Indicators to investigate (not proof of attack):"] + (pa.indicators(r) or ["None found. Normal traffic is not labeled malicious."]) + [
               "", "Field guide: src/dst = sender/receiver IP, sport/dport = ports (80 web, 443 secure web, 53 DNS), length = packet size in bytes."]
        return "\n".join(out)

    def key_start(self): self.sim.start(); self.key_in.configure(state="normal"); self.key_in.focus_set(); self.log_key("-- test started (simulator) --")
    def key_stop(self): self.sim.stop(); self.key_in.configure(state="disabled"); self.log_key("-- test stopped --")
    def key_clear(self): self.sim.clear(); self.put(self.key_log, "")
    def log_key(self, t): self.key_log.configure(state="normal"); self.key_log.insert("end", t + "\n"); self.key_log.see("end"); self.key_log.configure(state="disabled")
    def on_key(self, e):
        line = self.sim.record(e.keysym, e.char)
        if line: self.log_key(line)
    def key_export(self):
        try: p = self.sim.export(Path(self.cfg["export_dir"]) / f"keylab_demo_{rg.stamp()}.json"); self.log_key(f"Saved {p}")
        except OSError as exc: messagebox.showerror("Export failed", str(exc))

    def export(self, kind):
        if not self.recs: return messagebox.showinfo("Nothing to export", "The session is empty. Run a capture first.")
        d = Path(self.cfg["export_dir"]); s = rg.build_summary(self.recs, self.dur, {"protocol": self.proto_var.get(), "search": self.search.get()})
        try:
            p = {"csv": lambda: rg.export_csv(self.filtered(), d / f"packets_{rg.stamp()}.csv"), "json": lambda: rg.export_json(s, d / f"summary_{rg.stamp()}.json"),
                 "pdf": lambda: rg.export_pdf(s, d / f"report_{rg.stamp()}.pdf")}[kind]()
            self.reports += 1; self.rep_lbl.configure(text=f"Saved: {p}", text_color=C["accent"])
        except (OSError, ImportError) as exc: self.rep_lbl.configure(text=f"Export failed: {exc}", text_color=C["error"])

    def save_cfg(self):
        self.cfg = settings.validate({"duration": self.s_dur.get(), "export_dir": self.s_dir.get(), "row_limit": self.s_rows.get(), "confirm": self.s_conf.get(), "accent": self.s_acc.get()})
        try: settings.save(self.cfg); messagebox.showinfo("Saved", "Settings saved (invalid values were corrected).")
        except OSError as exc: messagebox.showerror("Error", str(exc))

    def clear_hist(self):
        if messagebox.askyesno("Clear", "Clear this session's data?"): self.recs.clear(); self.events = 0; self.dur = 0; self.refresh_page()

    # ---------- port scanner (pro) ----------
    def p_scan(self, f):
        self.scan_rows: list = []; self.scan_stop = threading.Event()
        self.label(f, "Scans only private/local IPs you own or may test (TCP connect scan, visible, no stealth).", C["warn"], ("Segoe UI", 11)).pack(anchor="w")
        bar = self.card(f); bar.pack(fill="x", pady=6)
        self.sc_target = ctk.CTkEntry(bar, width=150); self.sc_target.insert(0, "127.0.0.1"); self.sc_target.pack(side="left", padx=8, pady=8)
        self.sc_mode = ctk.StringVar(value="Common ports")
        ctk.CTkOptionMenu(bar, values=["Common ports", "Ports 1-1024", "Custom"], variable=self.sc_mode, width=130, fg_color="#14271f").pack(side="left")
        self.sc_custom = ctk.CTkEntry(bar, width=110, placeholder_text="21,80,443"); self.sc_custom.pack(side="left", padx=6)
        self.button(bar, "Scan", self.scan_start).pack(side="left", padx=3); self.button(bar, "Stop", lambda: self.scan_stop.set(), "#3a1520").pack(side="left", padx=3)
        self.button(bar, "Export", self.scan_export).pack(side="left", padx=3)
        bar2 = self.card(f); bar2.pack(fill="x")
        self.sc_net = ctk.CTkEntry(bar2, width=150); self.sc_net.insert(0, "192.168.1.0/24"); self.sc_net.pack(side="left", padx=8, pady=8)
        self.button(bar2, "ARP: find devices on my LAN", self.arp_start).pack(side="left")
        self.sc_box = self.term(f, 380); self.sc_box.pack(fill="both", expand=True, pady=6)
        self.put(self.sc_box, "Ready. Services shown: HTTP, HTTPS, FTP, SSH, DNS, SMB, RDP and more.\nNote: TCP only. A closed port does not mean a device is offline.")

    def sc_log(self, text):
        self.sc_box.configure(state="normal"); self.sc_box.insert("end", text + "\n"); self.sc_box.see("end"); self.sc_box.configure(state="disabled")

    def scan_start(self):
        try:
            target = ps.validate_target(self.sc_target.get())
            ports = ps.parse_ports({"Common ports": "common", "Ports 1-1024": "1-1024"}.get(self.sc_mode.get()) or self.sc_custom.get())
        except ValueError as exc:
            return self.put(self.sc_box, f"Cannot scan: {exc}")
        if not messagebox.askyesno("Authorized use", f"Scan {target}?\nOnly scan devices you own or have permission to test."): return
        self.scan_stop.clear(); self.scan_rows = []; self.events += 1
        self.put(self.sc_box, f"Scanning {target} ({len(ports)} ports)...\n")
        def work():
            rows = ps.scan(target, ports, lambda p, s: self.q.put(("scan", f"OPEN  {p:<6}{s}")), self.scan_stop)
            self.scan_rows = rows; self.q.put(("scan", f"-- finished: {len(rows)} open of {len(ports)} checked --"))
        threading.Thread(target=work, daemon=True).start()

    def arp_start(self):
        try: net = self.sc_net.get(); ps.ipaddress.ip_network(net, strict=False)
        except ValueError as exc: return self.put(self.sc_box, f"Bad network: {exc}")
        self.put(self.sc_box, f"ARP discovery on {net} (needs Npcap + Administrator)...\n")
        def work():
            try:
                for ip, mac in ps.arp_discover(net): self.q.put(("scan", f"DEVICE {ip:<16}{mac}"))
                self.q.put(("scan", "-- ARP discovery finished --"))
            except Exception as exc: self.q.put(("scan", f"ARP failed: {exc}"))
        threading.Thread(target=work, daemon=True).start()

    def scan_export(self):
        if not self.scan_rows: return self.put(self.sc_box, "Nothing to export. Run a scan first.")
        try: p = rg.export_scan(self.scan_rows, Path(self.cfg["export_dir"]) / f"scan_{rg.stamp()}.csv"); self.reports += 1; self.sc_log(f"Saved {p}")
        except OSError as exc: self.sc_log(f"Export failed: {exc}")

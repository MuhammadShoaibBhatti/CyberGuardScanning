"""CyberGuard Lab entry point."""
import logging
import sys

def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        from app.ui import App
    except ImportError as exc:
        print(f"Missing package: {exc}\nRun: python -m pip install -r requirements.txt")
        return 1
    App().mainloop()
    return 0

if __name__ == "__main__":
    sys.exit(main())
